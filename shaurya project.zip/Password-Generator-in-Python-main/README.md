# Password-Generator-in-Python

Password Generator is a simple application that can randomly generate passwords with a combination of letters, numbers and special characters based on a length given by the user using Python Tkinter module. The user can store the password along with their username in a database using Python SQLite3 module. The program only accepts users whose usernames have not been previously stored.

&nbsp;

![p1](https://user-images.githubusercontent.com/76877184/103482258-d88f3900-4e05-11eb-98e9-dd8518ebae09.PNG)

![p2](https://user-images.githubusercontent.com/76877184/103482259-d927cf80-4e05-11eb-83db-ff57a47f5db2.PNG)
